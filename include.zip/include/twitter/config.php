<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', '2CCnCiU66KcPkZ0RXbujlr4rT');
    define('CONSUMER_SECRET', '0chKprtbghB1pNbpRFGKJQrg77j18OEz5hXezWMkJNsCzfEw1D');

    // User Access Token
    define('ACCESS_TOKEN', '416341865-TCr1ufPx0K03cQZGABfQPMWFZcc65ZcocQzdKBWG');
    define('ACCESS_SECRET', 'ioikDRzyE2H09psrvJxd414VbCp73QX67qLvIio1IqJqQ');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));